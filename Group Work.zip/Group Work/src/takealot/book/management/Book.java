/*
     Chidi Chibuikem Iheanacho Chigbu - 223515760
     Katleho Oreratile Mesego Manana - 224119052
     Angel Adequate Bopape - 223412325
     Glad Maimele - 223561029
     Sibusiso Cebekulu - 223746819
 */

// declare package name
package takealot.book.management;

//// declare interface
//interface BookInterface {
//    String getSizeDetails();
//}

// declare abstract class Book
public abstract class Book {
     
     // instance variable for the book class
     private String title, author, isbnNo;
     
     //PARAMETERIZED CONSTRUCTOR 
     public Book(String title, String author, String isbnNo) {
          this.title = title;
          this.author = author;
          setIsbnNo(isbnNo);
     }
    
     //getters
     public String getTitle() {
          return title;
     }
     
     public String getAuthor() {
          return author;
     }
     
     public String getIsbnNo() {
          return isbnNo;
     }
     
     // setter method for isbnNo
     public void setIsbnNo(String isbnNo) {
          // ensure that isbn number is entered
          if (isbnNo.trim().isEmpty() ) {
              throw new IllegalArgumentException ( "The ISBN number must be entered"); 
        
          }
          // test isbn to be exactly 10 digits of length
          if (    !(isbnNo.length()  ==  10)    ) {
              throw new IllegalArgumentException ( "The ISBN number must be exactly 10 characters");
          }
          

          // test that it starts with 0 or 1
          if (  !isbnNo.startsWith("0")  &&  !isbnNo.startsWith("1") )  {
               throw new IllegalArgumentException ( "The ISBN number must start with numerical value of 0 or 1 ");
          }
          
          // use loop to go through the string to check if any character is a digit
          String firstNineDigits =isbnNo.substring(0, 9);
          
          for (int i = 0 ; i < firstNineDigits.length(); i++) {
               // test if character at position of i is a digit
               if ( !Character.isDigit(firstNineDigits.charAt(i)    ))  {
                   throw new IllegalArgumentException ( "The first nine digits must always be a numerical digit"); 
               }
          }

          //check that the 10th character is a digit or letter "B" or  "b"
          char tenthDigit = isbnNo.charAt(9);
          if ( !Character.isDigit(tenthDigit)  &&   tenthDigit != 'b'  && tenthDigit  !=  'B'       ) {
                   throw new IllegalArgumentException ( "The tenth digit must be a numerical value or either B or b");
          }
          
          //if no eception is caught assign 
          this.isbnNo = isbnNo;
 
     }
     
     //declare abstract method to be overrideen in the other classes
     public abstract  String getSizeDetails();
     
     
     
   
}
