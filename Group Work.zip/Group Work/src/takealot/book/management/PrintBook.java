/*
     Chidi Chibuikem Iheanacho Chigbu - 223515760
     Katleho Oreratile Mesego Manana - 224119052
     Angel Adequate Bopape - 223412325
     Glad Maimele - 223561029
     Sibusiso Cebekulu - 223746819
 */

package takealot.book.management;

public class PrintBook extends Book {
     
     private int noOfPages;
     private float weight;

     public PrintBook(int noOfPages, float weight, String title, String author, String isbnNo) {
          super(title, author, isbnNo);
          this.noOfPages = noOfPages;
          this.weight = weight;
     }

     public int getNoOfPages() {
          return noOfPages;
     }

     public float getWeight() {
          return weight;
     }
     
     @Override
     public String getSizeDetails() {
          return "Printbook : " + getTitle() + ", " + noOfPages + ", " + weight + "g";
     }
     
     
}
