/*
     Chidi Chibuikem Iheanacho Chigbu - 223515760
     Katleho Oreratile Mesego Manana - 224119052
     Angel Adequate Bopape - 223412325
     Glad Maimele - 223561029
     Sibusiso Cebekulu - 223746819
 */

package takealot.book.management;


public  class EBook extends Book {
     private int fileSize;

     public EBook(int fileSize, String title, String author, String isbnNo) {
          super(title, author, isbnNo);
          this.fileSize = fileSize;
     }

     public int getFileSize() {
          return fileSize;
     }
     
    
      @Override
     public  String getSizeDetails() {

          return "EBook : " + getTitle() + ", " + fileSize + " KB" ;
     }
    
   
     
}
