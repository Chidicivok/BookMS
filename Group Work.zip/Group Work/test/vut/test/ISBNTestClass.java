/*
     Chidi Chibuikem Iheanacho Chigbu - 223515760
     Katleho Oreratile Mesego Manana - 224119052
     Angel Adequate Bopape - 223412325
     Glad Maimele - 223561029
     Sibusiso Cebekulu - 223746819
 */

package vut.test;

import static org.junit.Assert.assertEquals;
import org.junit.Ignore;
import org.junit.Test;
import takealot.book.management.Book;
import takealot.book.management.EBook;
// import takealot.book.management.PrintBook;

public class ISBNTestClass {
     
     // call object to test the setisbn mutator
     // initialize ebook with format; int fileSize, String title, String author, String isbnNo
     Book objEBook = new EBook(0,"aTitle", "anAuthor", "0123456789");
    
     
     
     
//     // initialize print book with format int noOfPages, float weight, String title, String author, String isbnNo
//     Book objPrintBook = new PrintBook(0,0.0f,"aTitle", "anAuthor", "1234567890");
     @Ignore
     @Test
     public void testSetIsbno067001617B() {
        assertEquals(2,    1+1);
     }
     
     @Test
     public void testSetIsbno1367823245() {
     
          objEBook.setIsbnNo("1367823245");
          assertEquals("1367823245", objEBook.getIsbnNo() );
     }
     
     @Test
     public void testSetIsbno198734561B() {
    
          objEBook.setIsbnNo("198734561B");
          assertEquals("198734561B", objEBook.getIsbnNo() );
     }
     
     
     
     @Test (expected = IllegalArgumentException.class)
     public void testSetIsbno192156844() {
       
          objEBook.setIsbnNo("192156844");

     }
     
     @Test (expected = IllegalArgumentException.class)
     public void testSetIsbno032156B840() {
       
          objEBook.setIsbnNo("032156B840");
     }
     
     @Test
     public void testSetIsbno032156840b() {
    
          objEBook.setIsbnNo("032156840b");
          assertEquals("032156840b", objEBook.getIsbnNo() );
     }
     
     @Test (expected = IllegalArgumentException.class)
     public void testSetIsbno198734561K() {
       
          objEBook.setIsbnNo("198734561K");
     }
     
     
}
