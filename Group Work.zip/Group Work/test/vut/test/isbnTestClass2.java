
package vut.test;

import org.junit.Test;
import static org.junit.Assert.*;
import takealot.book.management.Book;
import takealot.book.management.EBook;
import takealot.book.management.PrintBook;


public class isbnTestClass2 {
     
  
     Book obj = new PrintBook(0,0,"the title", "the author" ,  "1234567890");
     
     
     @Test (expected = Exception.class)
     public void test1() {
          
          obj.setIsbnNo(  "1234K67890"  );

          
     }
     
    
     
     
     
     
     
     
     
     
     
}
