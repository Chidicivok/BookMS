
package vut.test;

import org.junit.Test;
import static org.junit.Assert.*;
import vut.data.Book;
import vut.data.EBook;


public class IsbnTestClass {
     
     Book obj = new EBook(0,"The picture of Dorian Gray", "Oscar Wilde", "1111111111");
     
      @Test
     public void testSetIsbno067001617B() {
          obj.setIsbnNo("067001617B");
          assertEquals("067001617B", obj.getIsbnNo() );
     }
     
     @Test
     public void testSetIsbno1367823245() {
          obj.setIsbnNo("1367823245");
          assertEquals("1367823245", obj.getIsbnNo() );
     }
     
     @Test
     public void testSetIsbno198734561B() {
          obj.setIsbnNo("198734561B");
          assertEquals("198734561B", obj.getIsbnNo() );
     }
     
     
     
     @Test (expected = IllegalArgumentException.class)
     public void testSetIsbno192156844() {
          obj.setIsbnNo("192156844");
     }
     
     @Test (expected = IllegalArgumentException.class)
     public void testSetIsbno032156B840() {
          obj.setIsbnNo("032156B840");
     }
     
     @Test
     public void testSetIsbno032156840b() {
          obj.setIsbnNo("032156840b");
          assertEquals("032156840b", obj.getIsbnNo() );
     }
     
     @Test (expected = IllegalArgumentException.class)
     public void testSetIsbno198734561K() {
          obj.setIsbnNo("198734561K");
     }

     
}
