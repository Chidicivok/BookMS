
package vut.data;

public abstract class Book {
     
     private String title;
     private String author;
     private String isbnNo;
     
     interface BookInterface {
          String getSizeDetails();
     }

     public Book(String title, String author, String isbnNo) {
          this.title = title;
          this.author = author;
          setIsbnNo(isbnNo);
     }

     public String getTitle() {
          return title;
     }

     public String getAuthor() {
          return author;
     }

     public String getIsbnNo() {
          return isbnNo;
     }
     
     
     public void setIsbnNo(String isbnNo) {
          
          if ( !(isbnNo.length()  ==  10) ) {
              throw new IllegalArgumentException ( "The ISBN number must be 10 characters long");
          }
          
          if (!isbnNo.startsWith("0") && !isbnNo.startsWith("1"))  {
               throw new IllegalArgumentException ( "The ISBN number must start with 0 or 1 ");
          }
          
          String first9 =isbnNo.substring(0, 9);
          
          for (int i = 0 ; i < first9.length(); i++) {         
               if ( !Character.isDigit(first9.charAt(i)))  {
                   throw new IllegalArgumentException ( "The first nine digits must always be a numerical digit"); 
               }
          }
          
          if (!Character.isDigit(isbnNo.charAt(9)) && isbnNo.charAt(9) != 'b' && isbnNo.charAt(9) != 'B') {
                   throw new IllegalArgumentException ( "The last character must be a numerical value or either B or b");
          }
          
          this.isbnNo = isbnNo;
          
     }
     
      public abstract  String getSizeDetails();

}
