
package vut.data;

public class EBook extends Book {
     
     private int fileSize;
     
     public EBook(int fileSize, String title, String author, String isbnNo) {
          super(title, author, isbnNo);
          this.fileSize = fileSize;
     }
     
      public int getFileSize() {
          return fileSize;
     }
      
      @Override
     public  String getSizeDetails() {
          return "EBook : " + getTitle() + ", " + fileSize + " KB" ;
     }
     
}
