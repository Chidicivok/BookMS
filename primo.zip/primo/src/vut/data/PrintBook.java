
package vut.data;

public class PrintBook extends Book {
     
     private int noOfPages;
     private float weight;
     
     public PrintBook(int noOfPages, float weight, String title, String author, String isbnNo) {
          super(title, author, isbnNo);
          this.noOfPages = noOfPages;
          this.weight = weight;
     }
     
      public int getNoOfPages() {
          return noOfPages;
     }

     public float getWeight() {
          return weight;
     }
     
     @Override
     public String getSizeDetails() {
          return "Printbook : " + getTitle() + ", " + noOfPages + ", " + weight + "g";
     }
     
}
